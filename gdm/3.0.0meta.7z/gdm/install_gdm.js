function Component()
{
    Component.prototype.createOperations = function()
    {
        component.createOperations();
        component.addOperation("CreateShortcut", "@TargetDir@/GdM.exe", "@StartMenuDir@/GdM.lnk",
            "workingDirectory=@TargetDir@", "iconId=2", "description=GdM - Gestionnaire de Copie");
        component.addOperation("CreateShortcut", "@TargetDir@/GdM.exe", "@DesktopDir@/GdM.lnk",
            "workingDirectory=@TargetDir@", "iconId=2", "description=GdM - Gestionnaire de Copie");
    }
}