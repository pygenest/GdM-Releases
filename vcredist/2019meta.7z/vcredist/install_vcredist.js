function Component()
{
    Component.prototype.createOperations = function()
    {
        component.createOperations();
        component.addOperation("Execute", "@TargetDir@/vc_redist.x64.exe");
    }
}